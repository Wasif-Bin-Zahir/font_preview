export default function ClipModal() {
  return <div></div>
}
