export default function Slider() {
  return <div></div>
}
