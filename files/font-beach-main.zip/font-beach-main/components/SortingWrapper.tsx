export default function SortingWrapper({
  children,
}: {
  children: React.ReactNode
}) {
  return <div></div>
}
