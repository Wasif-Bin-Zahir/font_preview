export default function SliderWrapper() {
  return <div></div>
}
