function Home() {
  return (
    <div className="min-h-screen flex text-4xl justify-center items-center">
      준비하고 있어요!
    </div>
  )
}

export default Home
