// // Import the functions you need from the SDKs you need
// import { initializeApp } from "firebase/app";
// import { getAnalytics } from "firebase/analytics";
// // TODO: Add SDKs for Firebase products that you want to use
// // https://firebase.google.com/docs/web/setup#available-libraries

// // Your web app's Firebase configuration
// // For Firebase JS SDK v7.20.0 and later, measurementId is optional
// const firebaseConfig = {
//   apiKey: "AIzaSyCUxDHDgsJ5_t5TO2XZ5i5dBhy1x6RE1j0",
//   authDomain: "font-beach.firebaseapp.com",
//   projectId: "font-beach",
//   storageBucket: "font-beach.appspot.com",
//   messagingSenderId: "115684085055",
//   appId: "1:115684085055:web:4bf52e2aef28373a41d78a",
//   measurementId: "G-V5L3P275FK"
// };

// // Initialize Firebase
// const app = initializeApp(firebaseConfig);
// const analytics = getAnalytics(app);
export const dummy = 1
