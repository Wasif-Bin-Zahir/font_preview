export type CategoryType = {
  id: string
  name: string
  slug: string
  description: string
  image: string
  createdAt: string
  updatedAt: string
}
