export type FontListItemType = {
  id: string
  name: string
  author: string
  description: string
  image: string
  createdAt: string
  commerce: boolean
  code: string
}
//
