# Font Beach - 폰트 비치
안녕하세요 👏 폰트 비치입니다.<br></br>
폰트 비치는 한글 텍스트 이미지를 다운로드하기 위해서 만들어진 웹앱입니다.
현재는 100개의 폰트를 지원하고 있습니다.(2023년 03월 03일 00:00 기준)<br></br>
계속해서 업데이트해서 폰트를 늘려갈 예정입니다.
앞으로 꾸준히 지켜봐 주세요~

# Font Beach 슬로건
폰트의 바다로 떠나요!

# Font Beach 로고

### DARK Version

<img width="300" src="https://user-images.githubusercontent.com/60413257/218294292-21e2dc6a-07d7-4e32-902d-f46dbbe76f66.png"/>

# Font Beach URL

<a href="https://www.fontbeach.com/">https://www.fontbeach.com/</a>
